#include <iostream>
using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	freopen("d.in", "r", stdin);
	freopen("d.out", "w", stdout);
	;
	cout << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}